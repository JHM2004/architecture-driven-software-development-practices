package com.alibaba.arms.mock.api;

/**
 * @author aliyun
 * @date 2021/07/22
 */
public interface IGreeting {

    String sayHi(String name);
}
