package com.alibaba.arms.mock.api;

/**
 * @author aliyun
 * @date 2022/03/14
 */
public interface IHello {

    String sayHello(String name);
}
