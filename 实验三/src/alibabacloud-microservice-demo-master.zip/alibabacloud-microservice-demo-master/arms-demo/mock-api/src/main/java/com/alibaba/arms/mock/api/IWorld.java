package com.alibaba.arms.mock.api;

/**
 * @author aliyun
 * @date 2022/03/14
 */
public interface IWorld {

    String sayWorld(String name);
}
