package com.alibaba.arms.mock.server.service;

/**
 * @author aliyun
 * @date 2021/07/09
 */
public abstract class AbstractComponent implements IComponent {

    @Override
    public void execute() {

    }
}
