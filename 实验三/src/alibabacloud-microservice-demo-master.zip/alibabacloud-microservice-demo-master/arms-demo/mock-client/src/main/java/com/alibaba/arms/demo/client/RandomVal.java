package com.alibaba.arms.demo.client;

public interface RandomVal<T> {

    public T getNextVal();
}
