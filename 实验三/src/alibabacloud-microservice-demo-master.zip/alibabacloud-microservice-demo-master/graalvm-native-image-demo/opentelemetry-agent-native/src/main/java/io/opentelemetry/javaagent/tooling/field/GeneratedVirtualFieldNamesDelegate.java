package io.opentelemetry.javaagent.tooling.field;

public class GeneratedVirtualFieldNamesDelegate {
    public static String getVirtualFieldImplementationClassName(String typeName, String fieldTypeName){
        return GeneratedVirtualFieldNames.getVirtualFieldImplementationClassName(typeName,fieldTypeName);
    }
}
