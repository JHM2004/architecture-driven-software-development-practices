package com.alibaba.edas.xml;

public interface DemoService {

    String sayHello(String name);

}
