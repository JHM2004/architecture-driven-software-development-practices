package com.alibaba.edas.api;

public interface GreetingsService {

    String sayHi(String name);
}
