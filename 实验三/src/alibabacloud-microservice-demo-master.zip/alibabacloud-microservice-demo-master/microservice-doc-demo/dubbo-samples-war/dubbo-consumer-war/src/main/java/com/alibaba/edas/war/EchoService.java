package com.alibaba.edas.war;

public interface EchoService {
    String echo(String name);
}
