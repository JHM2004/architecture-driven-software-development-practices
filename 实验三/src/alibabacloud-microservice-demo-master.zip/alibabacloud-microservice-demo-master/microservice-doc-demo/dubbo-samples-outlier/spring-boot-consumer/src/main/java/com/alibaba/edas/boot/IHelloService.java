package com.alibaba.edas.boot;

public interface IHelloService {
    String sayHello(String str);
}