package com.alibaba.edas.benchmark;

public interface OrderApi {

    OrderDTO queryOrder(long orderNo);

}
