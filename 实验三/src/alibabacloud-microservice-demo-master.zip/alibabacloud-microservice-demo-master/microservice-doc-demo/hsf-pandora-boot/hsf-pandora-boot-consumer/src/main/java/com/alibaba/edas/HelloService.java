package com.alibaba.edas;


public interface HelloService {
    String echo(String string);
}
