package com.aliyun.edas.book.model;

/**
 * @author jingfeng.xjf
 * @date 2023/9/26
 */
public class AuthorRequest {

    private String name;
    private String email;
    private int age;
    private IdCard idCard;

}
