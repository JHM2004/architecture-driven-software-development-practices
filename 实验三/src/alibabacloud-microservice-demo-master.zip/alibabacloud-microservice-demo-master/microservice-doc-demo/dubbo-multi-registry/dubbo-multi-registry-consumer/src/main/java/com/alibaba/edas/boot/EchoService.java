package com.alibaba.edas.boot;

public interface EchoService {
    String echo(String name);
}
